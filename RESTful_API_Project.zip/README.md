# RESTful API Project

**Owner:** Gaurav1148  

This project is a simple RESTful API built with Node.js and Express to manage users.

## Features
- Fetch all users
- Fetch user by ID
- Add a new user
- Update user details
- Delete a user
- Middleware for logging requests
- Middleware for validating POST and PUT requests
- In-memory data storage (Array)

## Requirements
- Node.js installed on your system
- Express package

## Setup Instructions
1. Clone or download this repository.
2. Navigate to the project folder in terminal.
3. Run:
   ```bash
   npm init -y
   npm install express
   node server.js
   ```
4. The server will run at:
   ```
   http://localhost:3000
   ```

## API Endpoints

### Get all users
**GET** `/users`

### Get user by ID
**GET** `/users/:id`

### Add a new user
**POST** `/user`  
Body:
```json
{
  "firstName": "Rahul",
  "lastName": "Sharma",
  "hobby": "Cricket"
}
```

### Update user
**PUT** `/user/:id`  
Body:
```json
{
  "firstName": "UpdatedName",
  "lastName": "UpdatedLastName",
  "hobby": "UpdatedHobby"
}
```

### Delete user
**DELETE** `/user/:id`

## Testing
Use **Postman** or **Thunder Client** to test endpoints.

---
**Author:** Gaurav1148  
